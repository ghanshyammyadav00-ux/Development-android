package com.apkbuilder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var tok: EditText
    private lateinit var repo: EditText
    private lateinit var log: TextView
    private lateinit var pick: Button
    private lateinit var go: Button
    private var zipUri: Uri? = null
    private var token = ""
    private var slug = ""

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { zipUri = u; pick.text = "ZIP chuna gaya"; say("Project ZIP ready.") }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun say(m: String) = runOnUiThread { log.text = m }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(16)) }
        col.addView(TextView(this).apply { text = "APK Builder"; textSize = 26f })
        tok = EditText(this).apply {
            hint = "GitHub token"; setText(sp.getString("tok", ""))
            inputType = 0x81 // text password
        }
        repo = EditText(this).apply { hint = "owner/repo"; setText(sp.getString("repo", "")) }
        pick = Button(this).apply { text = "Project ZIP chuno"; setOnClickListener { picker.launch(arrayOf("application/zip", "application/octet-stream")) } }
        go = Button(this).apply {
            text = "APK banao"
            setOnClickListener {
                if (zipUri == null) return@setOnClickListener say("Pehle ZIP chuno.")
                token = tok.text.toString().trim(); slug = repo.text.toString().trim()
                if (token.isEmpty() || !slug.contains("/")) return@setOnClickListener say("Token aur owner/repo bharo.")
                sp.edit().putString("tok", token).putString("repo", slug).apply()
                isEnabled = false
                Thread {
                    try { run() } catch (e: Exception) { say("Error: ${e.message}") }
                    runOnUiThread { isEnabled = true }
                }.start()
            }
        }
        log = TextView(this).apply { setPadding(0, dp(16), 0, 0); text = "Token aur repo bharo, ZIP chuno, phir APK banao." }
        listOf(tok, repo, pick, go).forEach { col.addView(it) }
        col.addView(ScrollView(this).apply { addView(log) })
        setContentView(col)
    }

    private fun gh(path: String, method: String = "GET", body: String? = null): JSONObject {
        val c = URL("https://api.github.com$path").openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val s = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code >= 400) throw Exception("GitHub $code: ${s.take(160)}")
        return JSONObject(s)
    }

    private fun run() {
        say("ZIP upload ho raha hai...")
        val bytes = contentResolver.openInputStream(zipUri!!)!!.use { it.readBytes() }
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        var sha: String? = null
        try { sha = gh("/repos/$slug/contents/project.zip").getString("sha") } catch (_: Exception) {}
        val body = JSONObject().put("message", "build ${System.currentTimeMillis()}").put("content", b64)
            .apply { if (sha != null) put("sha", sha) }.toString()
        val commit = gh("/repos/$slug/contents/project.zip", "PUT", body)
            .getJSONObject("commit").getString("sha")

        var runId = 0L; var st = ""; var cl = ""
        val end = System.currentTimeMillis() + 25 * 60_000
        while (st != "completed" && System.currentTimeMillis() < end) {
            Thread.sleep(6000)
            val r = gh("/repos/$slug/actions/runs?head_sha=$commit").getJSONArray("workflow_runs")
            if (r.length() > 0) {
                val o = r.getJSONObject(0)
                runId = o.getLong("id"); st = o.getString("status"); cl = o.optString("conclusion")
                say("Build: $st")
            } else say("Build queue me hai...")
        }
        if (cl != "success") throw Exception("Build fail ($cl). GitHub repo ke Actions tab me log dekho.")

        say("APK download ho raha hai...")
        val a = gh("/repos/$slug/actions/runs/$runId/artifacts").getJSONArray("artifacts").getJSONObject(0)
        val c = URL(a.getString("archive_download_url")).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.setRequestProperty("Authorization", "Bearer $token")
        val loc = c.getHeaderField("Location") ?: throw Exception("Download link nahi mila")
        val dir = File(cacheDir, "apks").apply { mkdirs() }
        val out = File(dir, "app.apk")
        ZipInputStream((URL(loc).openConnection() as HttpURLConnection).inputStream).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (e.name.endsWith(".apk")) { out.outputStream().use { z.copyTo(it) }; break }
                e = z.nextEntry
            }
        }
        if (!out.exists()) throw Exception("Artifact me APK nahi mila")
        say("APK ready. Install screen khul rahi hai...")
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", out)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
